<?php 

require_once('./vendor/autoload.php');
$tag = $_POST['number'];
    $gmail = $_POST['gmail'];
$paynow = new Paynow\Payments\Paynow(
    '19331',
    '69c787a8-1cef-415e-8ff6-d076cfcde4eb',
    'http://d8403290.ngrok.io/paynow-demo-php/examples/index.php?paynow-return=true',
    'http://d8403290.ngrok.io/paynow-demo-php/examples/callback.php'
);


$payment = $paynow->createPayment('Order 3', $gmail);


$payment->add('Sadza and Cold Water', 0.5)
        ->add('Sadza and Hot Water', 0.5);

// Optionally set a description for the order.
// By default, a description is generated from the items
// added to a payment
$payment->setDescription("Mr Maposa\'s lunch order");


// Initiate a Payment 
$response = $paynow->sendMobile($payment, $tag, 'ecocash');
if($response->success()) {
    // Or if you prefer more control, get the link to redirect the user to, then use it as you see fit
    $link = $response->redirectUrl();

    $pollUrl = $response->pollUrl();


    // Check the status of the transaction
    $status = $paynow->pollTransaction($pollUrl);

}

?>

